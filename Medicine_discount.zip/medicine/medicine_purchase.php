<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<div id="main" role="main">
    <div id="ribbon">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Medicine</a>
            </li>
            <li class="active">Medicine Purchase</li>
        </ul>
    </div>
    <div id="content">
        <div class="opt_msg">
            <?php
            $message = $this->session->userdata('message');
            $msg = $this->session->userdata('msg');

            if ($message) {
            ?>
                <div id="ribbon_msg">
                    <ol class="alert alert-warning">
                        <?php
                        echo '<font style="color:green">' . $message . '</font>';
                        $this->session->unset_userdata('message');
                        ?>
                    </ol>
                </div><?php
                    }
                        ?>
            <?php
            if ($msg) {
            ?>
                <div id="ribbon_msg">
                    <ol class="alert alert-warning">
                        <?php
                        echo '<font style="color:red">' . $msg . '</font>';
                        $this->session->unset_userdata('msg');
                        ?>
                    </ol>
                </div>
            <?php } ?>
        </div>
        <!-- END RIBBON_MESSAGE -->

        <div class="row">
            <div class="col-sm-12">
                <div class="well">
                    <div class="main-content">
                        <div class="main-content-inner">
                            <div class="page-content">
                                <div class="row">
                                    <div class="col-xl-12">

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 5%">#</th>
                                                    <th style="width: 20%">Medicine Name</th>
                                                    <th style="width: 15%">Quantity</th>
                                                    <th style="width: 20%;text-align: right">Rate</th>                                                   
                                                    <th style="width: 20%; text-align: right">Price</th>
                                                    <th style="width: 5%">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="view-purchase">

                                            </tbody>
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td>
                                                        <select class="form-control medicine-id" name="medicine_id">
                                                            <option value="">--Select Medicine--</option>
                                                            <?php
                                                            foreach ($medicine_list as $medicine) {
                                                            ?>
                                                                <option value="<?php echo $medicine['medicine_id'] ?>"><?php echo $medicine['medicine_name']; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </td>
                                                    <td><input type="text" value="" name="" class="form-control qty"></td>
                                                    <td><input type="text" value="" name="" class="form-control rate"></td>                                                   
                                                    <td><input type="text" readonly="" value="" name="" class="form-control price"></td>
                                                    <td><button class="btn btn-primary add-more-btn">Add More</button></td>
                                                </tr>
                                            </tbody>
                                           
                                        </table>

                                        <form action="<?php echo base_url(); ?>medicine_cost/save_medicine_purchase" method="post">
                                           
                                           <table class="table table-bordered">
                                                <tbody>
                                                    <tr>

                                                        <td>
                                                            Purchase Date:
                                                            <input type="text" readonly="" id="date1" name="purchase_date" class="form-control date-picker" value="<?php echo date('Y-m-d') ?>">
                                                        </td>
                                                        <td>
                                                            Purchase By:
                                                            <select class="select2" name="purchase_by">
                                                                <option value="">--Select One--</option>
                                                                <?php
                                                                foreach ($employee_list as $employee) {
                                                                ?>
                                                                    <option value="<?php echo $employee['employee_code'] ?>"><?php echo $employee['employee_code'] . '-' . $employee['employee_first_name'] . ' ' . $employee['employee_last_name'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            Discount:
                                                            <input type="text" name="discount" class="form-control discount">
                                                            <input type="hidden" name="t_price" class="form-control t_price">
                                                        </td>
                                                        


                                                        <td><input style="margin-top: 7%;" type="submit" value="Submit" name="Submit" id="discount_value" class="btn btn-info"></td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </form>
                                    </div><!-- /.col -->
                                </div><!-- /.row -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="well">
                    <div class="main-content">
                        <div class="main-content-inner">
                            <div class="page-content">
                                <div class="row">
                                    <div class="widget-body no-print">
                                        <div class="text-right">
                                            <div class="form-group form-inline">
                                                <form action="<?php echo base_url() . 'medicine_cost/medicine_purchase'; ?>" method="post">
                                                    <input type="text" readonly="" placeholder="Start Date" name="sdate" value="<?php echo $sdate ?>" id="date1" class="form-control date-picker">
                                                    <input type="text" readonly="" placeholder="End Date" name="edate" value="<?php echo $edate ?>" id="date2" class="form-control date-picker" required="">
                                                    <button type="submit" value="Submit!" class="btn btn-info">
                                                        Search
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="">
                                            <table class="table table-bordered" id="dt_basic">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Purchase Date</th>
                                                        <th>Medicine Name</th>
                                                        <th>Qty</th>
                                                        <th>Rate</th>
                                                        <th>Price</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $i = 1;
                                                    foreach ($purchase_data as $data) {
                                                    ?>
                                                        <tr>
                                                            <td><?php echo $i++; ?></td>
                                                            <td><?php echo $data->purchase_date; ?></td>
                                                            <td>
                                                                <?php
                                                                $this->db->where('medicine_id', $data->medicine_id);
                                                                echo $this->db->get('medicine_setting')->row('medicine_name');
                                                                ?>
                                                            </td>
                                                            <td><?php echo $data->qty ?></td>
                                                            <td style="text-align: right"><?php echo number_format($data->rate, 2) ?></td>
                                                            <td style="text-align: right"><?php echo number_format($data->price, 2) ?></td>
                                                            <td><a href="<?php echo base_url(); ?>medicine_cost/delete_medicine_purchase/<?php echo $data->purchase_id; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Do you want to delete this ?')"><i class="fa fa-trash-o"></i></a></td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    //$(document).ready(function(){
    // var total_val = $('.total_val').val();
    // var discount = $('.discount').val();
    $('.discount').keyup(function() {
                var total_val = $('.total_val').val();
                var discount = $('.discount').val();
                //alert(discount);
                var diff = (total_val - ((total_val) * (discount / 100)));
                // alert($('.discount').val());
                $('.total_val').val(diff);
                $('.t_price').val(diff);                                                                 
                  });
  </script>
<script>
    $(".add-more-btn").click(function() {
        var medicine_id = $(".medicine-id").val();
        var qty = $(".qty").val();
        var rate = $(".rate").val();       
        if (medicine_id == '') {
            alert("Medicine Name is Required");
        } else if (qty == '') {
            alert("Quantity is Required");
        } else if (rate == '') {
            alert("Rate is Required");
        } else {
            var data = {
                "medicine_id": medicine_id,
                "qty": qty,
                "rate": rate,              
            };
            $.ajax({
                type: 'POST',
                url: "<?php echo base_url(); ?>medicine_cost/add_to_cart_medicine_purchase",
                data: data,
                success: function(result) {
                    $('.view-purchase').html(result);
                    $(".medicine-id").val('');
                    $(".qty").val('');
                    $(".rate").val('');
                    $(".price").val('');                   
                }
            });
        }
    });
    $('.qty, .rate ').on('input', function() {
        var qty = $(".qty").val();
        var rate = $(".rate").val();      
        var price = qty * rate;     
        $(".price").val(price);
    });   
</script>