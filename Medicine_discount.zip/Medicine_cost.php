<?php

ob_start();

class medicine_cost extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == FALSE) {
            redirect(base_url() . 'login');
        }
        $this->load->model('medicine_cost_model');
        $this->load->library('cart');
    }

    public function medicine_cost_setting() {
        $data['title'] = 'Medicine Cost Setting';
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $data['setting_list'] = $this->medicine_cost_model->medicine_setting_list();
        $this->load->view('medicine/add_medicine', $data);
        $this->load->view('template/footer');
        $this->load->view('template/dtble');
    }

    public function save_medicine_name() {
        $data = array(
            'medicine_name' => $this->input->post('medicine_name'),
            'price' => $this->input->post('price')
        );
        $this->medicine_cost_model->medicine_cost_setting_insert_model($data);
        $sdata['message'] = "Sucessfully Save";
        $this->session->set_userdata($sdata);
        return redirect(base_url() . 'medicine_cost/medicine_cost_setting');
    }

    public function medicine_setting_edit($id = '') {
        $data['title'] = 'Medicine';
        $data['medicine'] = $this->medicine_cost_model->medicine_setting_name_edit_model($id);
        $this->load->view('template/header', $data);
        $this->load->view('medicine/edit_medicine', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('template/footer');
    }

    public function update_medicine() {
        $data = array(
            'medicine_name' => $this->input->post('medicine_name'),
            'price' => $this->input->post('price')
        );
        $id = $this->input->post('medicine_id');
        $this->medicine_cost_model->medicine_cost_setting_update_model($data, $id);
        $sdata['message'] = "Sucessfully Update";
        $this->session->set_userdata($sdata);
        return redirect(base_url() . 'medicine_cost/medicine_setting_edit/' . $id);
    }

    public function medicine_purchase() {
        $data['title'] = 'Medicine Purchase';
        $this->cart->destroy();
        if ($this->input->post()) {
            $data['sdate'] = $sdate = $this->input->post('sdate');
            $data['edate'] = $edate = $this->input->post('edate');
        } else {
            $data['sdate'] = $sdate = date("Y-m-01");
            $data['edate'] = $edate = date("Y-m-t");
        }
        $data['medicine_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['purchase_data'] = $this->medicine_cost_model->medicine_purchase_data($sdate, $edate);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/medicine_purchase', $data);
        $this->load->view('template/footer');
        $this->load->view('template/dtble');
    }

    public function medicine_cost_detail_insert($value = '') {
        $data = array(
            'purchase_date' => $this->input->post('purchase_date'),
            'medicine_id' => $this->input->post('medicine_id'),
            'quantity_packet' => $this->input->post('quantity_packet'),
            'quantity_pieces' => $this->input->post('quantity_pieces'),
            'amount' => $this->input->post('amount'),
            'purchase_by' => $this->input->post('purchase_by'),
        );

        $this->medicine_cost_model->medicine_cost_detail_insert_model($data);
        $this->medicine_purchase_detail();
    }

    public function medicine_cost_detail_edit($id = '') {
        $data['title'] = 'Medicine Cost Update';
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $data['setting_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['detail_list'] = $this->medicine_cost_model->medicine_detail_list();
        $data['editshow'] = $this->medicine_cost_model->medicine_detail_edit_id($id);
        $this->load->view('medicine_cost/medicine_purchase_detail_edit_view', $data);
        $this->load->view('template/footer');
    }

    public function medicine_cost_detail_update($id = '') {
        $data = array(
            'purchase_date' => $this->input->post('purchase_date'),
            'medicine_id' => $this->input->post('medicine_id'),
            'quantity_packet' => $this->input->post('quantity_packet'),
            'quantity_pieces' => $this->input->post('quantity_pieces'),
            'amount' => $this->input->post('amount'),
            'purchase_by' => $this->input->post('purchase_by'),
        );

        $this->medicine_cost_model->medicine_cost_detail_update_model($data, $id);
        $this->medicine_purchase_detail();
    }

    public function medicine_distribution() {
        $data['title'] = 'Medicine Distribution';
        $this->cart->destroy();
        $data['medicine_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['section'] = $this->medicine_cost_model->section_list();
        if ($this->input->post()) {
            $data['sdate'] = $sdate = $this->input->post('sdate');
            $data['edate'] = $edate = $this->input->post('edate');
        } else {
            $data['sdate'] = $sdate = date("Y-m-01");
            $data['edate'] = $edate = date("Y-m-t");
        }
        $data['distribution'] = $this->medicine_cost_model->get_medicine_distribution_data($sdate, $edate);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/medicine_distribution', $data);
        $this->load->view('template/footer');
        $this->load->view('template/dtble');
    }

    public function medicine_cost_discription_insert() {
        $data = array(
            'distribution_date' => $this->input->post('distribution_date'),
            'medicine_id' => $this->input->post('medicine_id'),
            'department_id' => $this->input->post('department_id'),
            'section_id' => $this->input->post('section_id'),
            'remark' => $this->input->post('remark'),
            'purchase_by' => $this->input->post('purchase_by'),
        );

        $this->medicine_cost_model->medicine_cost_discription_insert_model($data, $id);
        $this->medicine_distribution();
    }

    public function medicine_cost_description_edit($id = '') {
        $data['title'] = 'Medicine Cost Description';
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $data['setting_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['department'] = $this->medicine_cost_model->department_list();
        $data['section'] = $this->medicine_cost_model->section_list();
        $data['description'] = $this->medicine_cost_model->medicine_cost_description_list();
        $data['editshow'] = $this->medicine_cost_model->medicine_cost_description_edit_by($id);
        $this->load->view('medicine_cost/medicine_distribution_edit_view', $data);
        $this->load->view('template/footer');
    }

    public function medicine_report() {
        $data['title'] = "Medicine Report";
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/medicine_report', $data);
        $this->load->view('template/footer');
    }

    public function monthwise_medicine_report() {
        $year = $this->input->post('year');
        list($start_year, $end_year) = explode("-", $year);
        $data['start_year'] = $start_year;
        $data['end_year'] = $end_year;
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine_cost/monthwise_medicine_report', $data);
        $this->load->view('template/footer');
    }

    public function monthwise_medicine_distribution_report() {
        $year = $this->input->post('year');
        list($start_year, $end_year) = explode("-", $year);
        $data['start_year'] = $start_year;
        $data['end_year'] = $end_year;
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine_cost/monthwise_medicine_distribution_report', $data);
        $this->load->view('template/footer');
    }

    public function department_wise_medicine_distribution($start_date, $end_date) {
        $data['title'] = "Medicine Distribution Report";
        $data['department'] = $this->department_model->view_department();
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine_cost/department_wise_medicine_distribution', $data);
        $this->load->view('template/footer');
    }

    public function section_wise_medicine_distribution($dept, $start_date, $end_date) {
        $data['title'] = "Medicine Distribution Report";
        $data['section'] = $this->report_model->get_section_by_department($dept);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine_cost/section_wise_medicine_distribution', $data);
        $this->load->view('template/footer');
    }

    public function add_to_cart_medicine() {
        //$medicine_name = 
    }

    public function add_to_cart_medicine_purchase() {

        $medicine_id = $this->input->post('medicine_id');
        $qty = $this->input->post('qty');
        $rate = $this->input->post('rate');
        $this->db->where('medicine_id', $medicine_id);
        $medicine_name = $this->db->get('medicine_setting')->row('medicine_name');
        $data = array(
            'id' => $medicine_id,
            'name' => $medicine_name,
            'qty' => $qty,
            'price' => $rate
        );
        $this->cart->insert($data);
        $this->view_medicine_purchase();
    }

    public function add_to_cart_medicine_distribution() {
        $medicine_id = $this->input->post('medicine_id');
        $qty = $this->input->post('qty');
        $rate = $this->input->post('rate');
        $this->db->where('medicine_id', $medicine_id);
        $medicine_name = $this->db->get('medicine_setting')->row('medicine_name');
        $data = array(
            'id' => $medicine_id,
            'name' => $medicine_name,
            'qty' => $qty,
            'price' => $rate
        );
        $this->cart->insert($data);
        $this->view_medicine_distribution();
    }

    public function view_medicine_purchase() {
        $i = 1;
        $total_price = 0;
        foreach ($this->cart->contents() as $cart) {
            $total_price += ($cart['price'] * $cart['qty']);
            echo '<tr>';
            echo '<td>' . $i++ . '</td>';
            echo '<td>' . $cart['name'] . '</td>';
            echo '<td>' . $cart['qty'] . '</td>';
            echo '<td style="text-align:right">' . number_format($cart['price'], 2) . '</td>';
            echo '<td style="text-align:right">' . number_format($cart['price'] * $cart['qty'], 2) . '</td>';
            echo '<td></td>';
            echo '<tr>';
        }
        if ($total_price) {
            echo '<tr>';
            echo '<th colspan="4">Total</th>';
            echo '<th style="text-align:right"><input style="text-align:right" type="text" name="total_price" readonly="" class="form-control total_val" value=' . " $total_price " . '></th>';
            echo '<td></td>';
            echo '<tr>';
        }
    }

    public function view_medicine_distribution() {
        $i = 1;
        $total_price = 0;
        foreach ($this->cart->contents() as $cart) {
            $total_price += ($cart['price'] * $cart['qty']);
            echo '<tr>';
            echo '<td>' . $i++ . '</td>';
            echo '<td>' . $cart['name'] . '</td>';
            echo '<td>--</td>';
            echo '<td>' . $cart['qty'] . '</td>';
            echo '<td style="text-align:right">' . number_format($cart['price'], 2) . '</td>';
            echo '<td style="text-align:right">' . number_format($cart['price'] * $cart['qty'], 2) . '</td>';
            echo '<td></td>';
            echo '<tr>';
        }
        if ($total_price) {
            echo '<tr>';
            echo '<th colspan="5">Total</th>';
            echo '<th style="text-align:right">' . number_format($total_price, 2) . '</th>';
            echo '<td></td>';
            echo '<tr>';
        }
    }

    public function save_medicine_purchase() {
        $discount_price = $this->input->post('t_price');       
        $purchase_date = $this->input->post('purchase_date');
        $purchase_by = $this->input->post('purchase_by');
        foreach ($this->cart->contents() as $cart) {
            
            $save_data = array(
                'purchase_date' => $purchase_date,
                'purchase_by' => $purchase_by,
                'medicine_id' => $cart['id'],
                'qty' => $cart['qty'],
                'rate' => $cart['price'],                
                'price' => $discount_price
            );
            $this->db->insert('medicine_purchase', $save_data);

            $this->db->where('medicine_id', $cart['id']);
            $medicine = $this->db->get('medicine_setting')->row();

            if ($medicine->price) {
                $update_data['price'] = ($medicine->price + $cart['price']) / 2;
            } else {
                $update_data['price'] = $cart['price'];
            }
            $update_data['stock_qty'] = $cart['qty'];
            $this->db->where('medicine_id', $cart['id']);
            $this->db->update('medicine_setting', $update_data);
        }
        $sdata['message'] = "Sucessfully Purchase Medicine";
        $this->session->set_userdata($sdata);
        return redirect(base_url() . 'medicine_cost/medicine_purchase');
    }

    public function delete_medicine_purchase($purchase_id) {
        $this->db->where('purchase_id', $purchase_id);
        $this->db->delete('medicine_purchase');
        return redirect('medicine_cost/medicine_purchase');
    }

    public function get_medicine_rate_stock($medicine_id) {
        $this->db->where('medicine_id', $medicine_id);
        $query = $this->db->get('medicine_setting');
        $data = $query->row();
        echo json_encode($data);
    }

    public function save_medicine_distribution() {
        foreach ($this->cart->contents() as $cart) {
            $save_data = array(
                'distribution_date' => $this->input->post('distribution_date'),
                'receive_by' => $this->input->post('receive_by'),
                'section_id' => $this->input->post('section_id'),
                'medicine_id' => $cart['id'],
                'qty' => $cart['qty'],
                'rate' => $cart['price'],
                'price' => $cart['qty'] * $cart['price']
            );
            $this->db->insert('medicine_distribution', $save_data);

            $this->db->where('medicine_id', $cart['id']);
            $medicine = $this->db->get('medicine_setting')->row();
            $update_data['stock_qty'] = $medicine->stock_qty - $cart['qty'];
            $this->db->where('medicine_id', $cart['id']);
            $this->db->update('medicine_setting', $update_data);
        }
        $sdata['message'] = "Successfully Distribute Medicine";
        $this->session->set_userdata($sdata);
        return redirect('medicine_cost/medicine_distribution');
    }

    public function medicine_purchase_and_distribution_report() {
        $data['title'] = "Medicine Distribution Report";
        if ($this->input->post()) {
            $year = $this->input->post('year');
        } else {
            if (date('m') < 7) {
                $year = (date("Y") - 1) . '-' . date('Y');
            } else {
                $year = date("Y") . '-' . (date('Y') + 1);
            }
        }
        $data['setYear'] = $year;
        list($start_year, $end_year) = explode("-", $year);
        $data['start_year'] = $start_year;
        $data['end_year'] = $end_year;
        for ($i = 7; $i <= 18; $i++) {
            if ($i > 12) {
                $month = $i - 12;
                $y = $end_year;
            } else {
                $month = $i;
                $y = $start_year;
            }
            $mnth = DateTime::createFromFormat("!m", $month);
            $monthName = $mnth->format('F');
            $sdate = $y . '-' . $month . '-01';
            $edate = $y . '-' . $month . '-31';
            $purchase_amount = $this->medicine_cost_model->get_medicine_purchase_amount($sdate, $edate);
            $distribution_amount = $this->medicine_cost_model->get_medicine_distribution_amount($sdate, $edate);
            $medicine_data[] = array(
                'sdate' => $sdate,
                'edate' => $edate,
                'monthName' => $monthName . ', ' . $y,
                'purchaseAmount' => $purchase_amount->total_price,
                'distributionAmount' => $distribution_amount->total_price
            );
        }
        $data['medicine_data'] = $medicine_data;
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/medicine_purchase_and_distribution_report', $data);
        $this->load->view('template/footer');
    }

    public function monthly_medicine_purchase($sdate = '', $edate = '') {
        $data['title'] = 'Medicine Purchase';
        $data['medicine_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['purchase_data'] = $this->medicine_cost_model->medicine_purchase_data($sdate, $edate);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/monthly_medicine_purchase', $data);
        $this->load->view('template/footer');
        $this->load->view('template/dtble');
    }

    public function monthly_medicine_distribution($sdate = '', $edate = '') {
        $data['title'] = 'Medicine Distribution';
        $data['medicine_list'] = $this->medicine_cost_model->medicine_setting_list();
        $data['employee_list'] = $this->medicine_cost_model->employee_list();
        $data['section'] = $this->medicine_cost_model->section_list();
        $data['distribution'] = $this->medicine_cost_model->get_medicine_distribution_data($sdate, $edate);
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/monthly_medicine_distribution', $data);
        $this->load->view('template/footer');
        $this->load->view('template/dtble');
    }

    public function medicine_stock_report() {
        $data['title'] = "Medicine Stock Report";
        $data['medicine_list'] = $this->medicine_cost_model->medicine_setting_list();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidemenu');
        $this->load->view('medicine/medicine_stock_report', $data);
        $this->load->view('template/footer');
    }

}
